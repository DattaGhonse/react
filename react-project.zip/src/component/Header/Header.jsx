import { Navbar, Container, Nav, NavDropdown, Dropdown } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import menu from './../json-api/menu.json';
import brand from './../json-api/brand.json';

const Menu = ({ item }) => {
  return (
    <Link data-bs-dismiss="Navbar" to={item.link} className="nav-link">
      {item.label}
    </Link>
  );
};

const DropdownMenu = ({ item }) => {
  return (
    <>
      <NavDropdown title={item.label} id="navbarScrollingDropdown">
        {item.dropdownMenu.map((data, index) => {
          return <Menu item={data} key={index} />;
        })}
      </NavDropdown>
    </>
  );
};
const Header = () => {
  console.log(menu);
  return (
    <>
      <Navbar collapseOnSelect expand="lg" className="bg-body-tertiary">
        <Container>
          <img src={brand.logo} width="40px" alt="" />
          <Navbar.Brand href="#home" className="mx-3 fw-bold">
            {brand.name}
          </Navbar.Brand>
          <Navbar.Toggle aria-controls="responsive-navbar-nav" />
          <Navbar.Collapse id="responsive-navbar-nav">
            <Nav className="justify-content-end w-100">
              {menu.map((item, index) => {
                if (item.isDropdown) {
                  return <DropdownMenu key={index} item={item} />;
                }
                return <Menu item={item} key={index} />;
              })}
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>
    </>
  );
};

export default Header;
