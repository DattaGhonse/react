const Footer = () =>{
  return(
    <>
      <h1>Welcome to footer</h1>
    </>
  )
}

export default Footer;