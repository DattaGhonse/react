import { Container } from 'react-bootstrap';
import Footer from './component/Footer/Footer';
import Header from './component/Header/Header';
import 'bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
const App = () => {
  return (
    <>
      <BrowserRouter>
        <Header />
        <Container>
          <Routes>
            <Route path="/" element={<h1>Welcome to homepage</h1>} />
            <Route path="/link" element={<h1>Welcome to Link page</h1>} />
            <Route path="/blog" element={<h1>Welcome to Blog page</h1>} />
            <Route path="/website" element={<h1>Welcome to website page</h1>} />
            <Route path="/team" element={<h1>Welcome to team page</h1>} />
            <Route path="/contact" element={<h1>Welcome to contact page</h1>} />
            <Route path="/images" element={<h1>Welcome to images page</h1>} />
          </Routes>
        </Container>
      </BrowserRouter>
    </>
  );
};
export default App;
