import 'bootstrap/dist/css/bootstrap.min.css';
import 'animate.css/animate.min.css';
import { Button } from 'react-bootstrap';
const Homepage = () => {
  return (
    <>
      <h1>Welcome to Homepage</h1>
      <h1>Hello Users</h1>
      <Button variant="danger">Click Me</Button>
    </>
  );
};

export default Homepage;
