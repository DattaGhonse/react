import './Navbar.css';
import { Link } from 'react-router-dom';
const Navbar = () => {
  return (
    <>
      <ul>
        <li>
          <img
            src="https://cdn.iconscout.com/icon/free/png-256/free-react-1-282599.png?f=webp&w=256"
            width="30"
            alt=""
          />
        </li>
        <li>
          <Link to="/">Home</Link>
        </li>
        <li>
          <Link to="/about">About</Link>
        </li>
        <li>
          <Link to="/team">Team</Link>
        </li>
        <li>
          <Link to="/services">Services</Link>
        </li>
        <li>
          <Link to="/images">Images</Link>
        </li>
        <li>
          <Link to="/gallery">Gallery</Link>
        </li>
      </ul>
    </>
  );
};
export default Navbar;
