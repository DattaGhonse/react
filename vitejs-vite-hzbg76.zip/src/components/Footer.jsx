import './Footer.css';
const Footer = () => {
  return (
    <>
      <div className="container">
        <h2>Footer</h2>
      </div>
    </>
  );
};
export default Footer;
