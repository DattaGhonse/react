import './App.css';
import Footer from './components/Footer';
import Navbar from './components/Navbar';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Homepage from './components/Homepage';
const App = () => {
  return (
    <>
      <BrowserRouter>
        <Navbar />
        <div className="page">
          <div className="container">
            <Routes>
              <Route path="/" element={<Homepage />} />
              <Route path="/about" element={<h1>Welcome to About</h1>} />
              <Route path="/team" element={<h1>Welcome to Team</h1>} />
              <Route path="/services" element={<h1>Welcome to services</h1>} />
              <Route path="/images" element={<h1>Welcome to images</h1>} />
              <Route path="/gallery" element={<h1>Welcome to gallery</h1>} />
            </Routes>
          </div>
        </div>
        <Footer />
      </BrowserRouter>
    </>
  );
};
export default App;
